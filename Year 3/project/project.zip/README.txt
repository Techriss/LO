lista zadań

w projekcie można dodać zadanie, usunąć je lub zmieniać jego dokonanie (checkbox po lewej)

aby działał poprawnie, należy w plikach view.php, add.php, delete.php i update.php zmienić nazwę bazy danych na istniejącą i potencjalnie hasło
